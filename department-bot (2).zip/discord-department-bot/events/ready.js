const { Events, ActivityType } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    console.log(`📊 Serving ${client.guilds.cache.size} guild(s)`);
    
    client.user.setPresence({
      activities: [{ name: 'the Department | /help', type: ActivityType.Watching }],
      status: 'online',
    });
  },
};
