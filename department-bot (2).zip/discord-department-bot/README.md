# Department Bot — All-in-One Discord Management

A complete Discord bot for running a department (Police, Fire, EMS, Military, Staff team, etc.).

## Features

### Moderation & Infractions
- `/warn` — Warn + points
- `/mute` / `/unmute` — Timeout system
- `/kick` / `/ban` — Kick & ban with logging
- `/history` — Full infraction history + points
- `/note` — Private staff notes
- `/clearinfractions` — Reset points (Admin)
- `/purge` — Bulk message delete

### Ranks & Promotions
- `/promote` — Promote with role + reason + DM
- `/demote` — Remove rank role
- `/promohistory` — Full promotion history

### Utility & Admin
- `/userinfo` — Detailed profile (roles, points, notes, promo history)
- `/setup` — Configure log channels
- `/blacklist` — Add / remove / check / list blacklisted users
- `/help` — Command list

### System
- SQLite database (no external DB needed)
- Automatic action logging to staff channels
- DM notifications to punished/promoted members
- Proper hierarchy & permission checks
- Point system with configurable values

---

## Setup Guide

### 1. Create the Bot Application
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click **New Application** → name it
3. Go to **Bot** tab → **Add Bot**
4. Under **Privileged Gateway Intents** enable:
   - Server Members Intent
   - Message Content Intent
5. Copy the **Bot Token**
6. Go to **OAuth2 → General** and copy the **Client ID** (Application ID)

### 2. Invite the Bot
1. OAuth2 → URL Generator
2. Scopes: `bot` + `applications.commands`
3. Bot Permissions: 
   - Manage Roles
   - Kick Members
   - Ban Members
   - Moderate Members
   - Manage Messages
   - Read Message History
   - Send Messages
   - Embed Links
   - View Channels
4. Copy the URL and open it → select your server

### 3. Install & Configure
```bash
# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env with your values
# DISCORD_TOKEN=...
# CLIENT_ID=...
# GUILD_ID=...   (your server ID - optional but recommended)
```

### 4. Deploy Commands
```bash
npm run deploy
```

### 5. Start the Bot
```bash
npm start
```

### 6. Configure Logging
In your Discord server run:
```
/setup mod_log:#your-mod-logs promo_log:#your-promo-logs
```

---

## Customization

Edit `config.js` to change:
- Point values for each infraction type
- Embed colors
- Default log channel IDs
- Rank hierarchy (optional)

---

## Recommended Role Hierarchy
Bot role should be placed **above** the ranks it needs to manage, but below Server Owner / high admins.

---

## Future Additions (easy to expand)
- Ticket system
- Shift / clock-in system
- Staff application forms
- LOA (Leave of Absence) system
- Activity tracking
- Appeal system
- Automatic escalation based on points

Just ask if you want any of these added!
