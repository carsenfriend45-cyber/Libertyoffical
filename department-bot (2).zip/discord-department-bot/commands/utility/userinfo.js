const { SlashCommandBuilder } = require('discord.js');
const { statements } = require('../../database/db');
const { userInfoEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View detailed information about a member')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to view').setRequired(false)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

    if (!member) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found in this server.')], ephemeral: true });
    }

    const infractions = statements.getActiveInfractions.all(interaction.guild.id, member.id);
    const points = statements.getTotalPoints.get(interaction.guild.id, member.id).total;
    const notes = statements.getNotes.all(interaction.guild.id, member.id);
    const promotions = statements.getPromotions.all(interaction.guild.id, member.id);

    const embed = userInfoEmbed(member, infractions, points, notes, promotions);
    await interaction.reply({ embeds: [embed] });
  }
};
