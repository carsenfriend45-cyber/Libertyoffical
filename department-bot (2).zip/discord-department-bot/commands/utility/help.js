const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available commands'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(config.colors.info)
      .setTitle('Department Bot — Command List')
      .setDescription('All-in-one moderation, infractions & rank management bot.')
      .addFields(
        {
          name: '🛡️ Moderation',
          value: 
            '`/warn` — Warn a member\n' +
            '`/mute` — Timeout a member\n' +
            '`/unmute` — Remove timeout\n' +
            '`/kick` — Kick a member\n' +
            '`/ban` — Ban a member\n' +
            '`/purge` — Delete messages\n' +
            '`/history` — View infractions\n' +
            '`/note` — Add staff note\n' +
            '`/clearinfractions` — Reset points (Admin)'
        },
        {
          name: '⬆️ Ranks & Promotions',
          value:
            '`/promote` — Promote a member\n' +
            '`/demote` — Demote a member\n' +
            '`/promohistory` — View promo history'
        },
        {
          name: '🔧 Utility & Admin',
          value:
            '`/userinfo` — Detailed user info\n' +
            '`/setup` — Configure log channels (Admin)\n' +
            '`/blacklist` — Manage blacklist (Admin)\n' +
            '`/help` — This menu'
        }
      )
      .setFooter({ text: 'Use the commands with / in Discord' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
