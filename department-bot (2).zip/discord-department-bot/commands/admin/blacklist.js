const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('Manage the department blacklist')
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a user to the blacklist')
        .addUserOption(opt => opt.setName('user').setDescription('User to blacklist').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a user from the blacklist')
        .addUserOption(opt => opt.setName('user').setDescription('User to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('check')
        .setDescription('Check if a user is blacklisted')
        .addUserOption(opt => opt.setName('user').setDescription('User to check').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all blacklisted users')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'Administrator only.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason');

      statements.addBlacklist.run(interaction.guild.id, user.id, reason, interaction.user.id);

      await interaction.reply({
        embeds: [successEmbed('Blacklisted', `**${user.tag}** has been added to the blacklist.\n**Reason:** ${reason}`)]
      });

      const log = logEmbed(
        '🚫 User Blacklisted',
        `**User:** ${user.tag} (\`${user.id}\`)\n**Moderator:** ${interaction.member}\n**Reason:** ${reason}`,
        config.colors.error
      );
      await sendLog(interaction.guild, 'moderation', log);
    }

    else if (sub === 'remove') {
      const user = interaction.options.getUser('user');
      statements.removeBlacklist.run(interaction.guild.id, user.id);

      await interaction.reply({
        embeds: [successEmbed('Removed', `**${user.tag}** has been removed from the blacklist.`)]
      });
    }

    else if (sub === 'check') {
      const user = interaction.options.getUser('user');
      const entry = statements.isBlacklisted.get(interaction.guild.id, user.id);

      if (entry) {
        await interaction.reply({
          embeds: [
            errorEmbed(
              'Blacklisted',
              `**${user.tag}** is blacklisted.\n**Reason:** ${entry.reason}\n**By:** <@${entry.moderator_id}>\n**Date:** <t:${Math.floor(new Date(entry.created_at).getTime() / 1000)}:F>`
            )
          ],
          ephemeral: true
        });
      } else {
        await interaction.reply({
          embeds: [successEmbed('Not Blacklisted', `**${user.tag}** is not on the blacklist.`)],
          ephemeral: true
        });
      }
    }

    else if (sub === 'list') {
      const list = statements.getBlacklist.all(interaction.guild.id);

      if (list.length === 0) {
        return interaction.reply({
          embeds: [successEmbed('Blacklist Empty', 'No users are currently blacklisted.')],
          ephemeral: true
        });
      }

      const description = list.slice(0, 20).map(b => 
        `• <@${b.user_id}> — ${b.reason}\n└ by <@${b.moderator_id}>`
      ).join('\n\n');

      const embed = new EmbedBuilder()
        .setColor(config.colors.error)
        .setTitle('Department Blacklist')
        .setDescription(description)
        .setFooter({ text: `Total: ${list.length}` })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
