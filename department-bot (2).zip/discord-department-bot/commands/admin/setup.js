const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Configure the department bot for this server')
    .addChannelOption(opt =>
      opt.setName('mod_log')
        .setDescription('Channel for moderation & infraction logs')
        .addChannelTypes(ChannelType.GuildText)
    )
    .addChannelOption(opt =>
      opt.setName('promo_log')
        .setDescription('Channel for promotion / demotion logs')
        .addChannelTypes(ChannelType.GuildText)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'Administrator only.')], ephemeral: true });
    }

    const modLog = interaction.options.getChannel('mod_log');
    const promoLog = interaction.options.getChannel('promo_log');

    const existing = statements.getSettings.get(interaction.guild.id) || {};

    statements.setSettings.run(
      interaction.guild.id,
      modLog?.id || existing.mod_log_channel || null,
      promoLog?.id || existing.promo_log_channel || null,
      modLog?.id || existing.infraction_log_channel || null,
      existing.mute_role || null,
      existing.prefix || '!'
    );

    await interaction.reply({
      embeds: [
        successEmbed(
          'Bot Configured',
          `**Mod / Infraction Log:** ${modLog || existing.mod_log_channel ? `<#${modLog?.id || existing.mod_log_channel}>` : 'Not set'}\n` +
          `**Promotion Log:** ${promoLog || existing.promo_log_channel ? `<#${promoLog?.id || existing.promo_log_channel}>` : 'Not set'}\n\n` +
          `You can re-run this command anytime to update settings.`
        )
      ],
      ephemeral: true
    });
  }
};
