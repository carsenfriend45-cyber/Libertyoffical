const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canManageRoles, isHigher, botCanActOn } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('Promote a member to a higher rank')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to promote').setRequired(true)
    )
    .addRoleOption(opt =>
      opt.setName('rank').setDescription('New rank role').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for promotion').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const newRole = interaction.options.getRole('rank');
    const reason = interaction.options.getString('reason');
    const moderator = interaction.member;

    if (!target) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found.')], ephemeral: true });
    }

    if (!canManageRoles(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You need Manage Roles permission.')], ephemeral: true });
    }

    if (!isHigher(moderator, target)) {
      return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot promote this user.')], ephemeral: true });
    }

    if (!botCanActOn(interaction.guild.members.me, target)) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'I cannot manage this user\'s roles.')], ephemeral: true });
    }

    if (newRole.position >= interaction.guild.members.me.roles.highest.position) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'That role is higher than my highest role.')], ephemeral: true });
    }

    if (newRole.position >= moderator.roles.highest.position && interaction.guild.ownerId !== moderator.id) {
      return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot assign a role equal or higher than your own.')], ephemeral: true });
    }

    // Find current highest rank role (from config if set, otherwise just track the new one)
    const currentRoles = target.roles.cache.filter(r => r.id !== interaction.guild.id);
    const fromRank = currentRoles.sort((a, b) => b.position - a.position).first()?.name || 'None';

    try {
      await target.roles.add(newRole, reason);
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', `Could not add role: ${err.message}`)], ephemeral: true });
    }

    statements.addPromotion.run(
      interaction.guild.id,
      target.id,
      moderator.id,
      'promote',
      fromRank,
      newRole.name,
      reason
    );

    try {
      await target.send({
        embeds: [{
          color: 0x57F287,
          title: '🎉 You have been promoted!',
          description: `**Server:** ${interaction.guild.name}\n**New Rank:** ${newRole.name}\n**Reason:** ${reason}\n**By:** ${moderator.user.tag}`,
          timestamp: new Date().toISOString()
        }]
      });
    } catch {}

    await interaction.reply({
      embeds: [
        successEmbed(
          'Member Promoted',
          `**User:** ${target}\n**New Rank:** ${newRole}\n**Previous:** ${fromRank}\n**Reason:** ${reason}`
        )
      ]
    });

    const log = logEmbed(
      '⬆️ Member Promoted',
      `**User:** ${target} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**From:** ${fromRank}\n**To:** ${newRole.name}\n**Reason:** ${reason}`,
      config.colors.promote
    );
    await sendLog(interaction.guild, 'promotions', log);
  }
};
