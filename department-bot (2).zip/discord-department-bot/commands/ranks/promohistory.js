const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { statements } = require('../../database/db');
const { errorEmbed, infoEmbed } = require('../../utils/embeds');
const { canManageRoles } = require('../../utils/permissions');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promohistory')
    .setDescription('View a member\'s promotion / demotion history')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to check').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const moderator = interaction.member;

    if (!canManageRoles(moderator) && !moderator.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'Insufficient permissions.')], ephemeral: true });
    }

    const history = statements.getPromotions.all(interaction.guild.id, target.id);

    if (history.length === 0) {
      return interaction.reply({
        embeds: [infoEmbed('No History', `${target.tag} has no recorded promotions or demotions.`)],
        ephemeral: true
      });
    }

    const list = history.slice(0, 15).map(p => {
      const icon = p.action === 'promote' ? '⬆️' : '⬇️';
      return `${icon} **${p.action.toUpperCase()}** — ${p.from_rank || 'N/A'} → ${p.to_rank || 'N/A'}\n└ Reason: ${p.reason || 'None'}\n└ <t:${Math.floor(new Date(p.created_at).getTime() / 1000)}:R> by <@${p.moderator_id}>`;
    }).join('\n\n');

    const embed = new EmbedBuilder()
      .setColor(config.colors.info)
      .setTitle(`Promotion History — ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .setDescription(list)
      .setFooter({ text: `Total records: ${history.length}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
