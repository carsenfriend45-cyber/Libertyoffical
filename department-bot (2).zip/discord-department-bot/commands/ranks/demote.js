const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canManageRoles, isHigher, botCanActOn } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('demote')
    .setDescription('Demote a member (remove a rank role)')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to demote').setRequired(true)
    )
    .addRoleOption(opt =>
      opt.setName('rank').setDescription('Rank role to remove').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for demotion').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const rankRole = interaction.options.getRole('rank');
    const reason = interaction.options.getString('reason');
    const moderator = interaction.member;

    if (!target) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found.')], ephemeral: true });
    }

    if (!canManageRoles(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You need Manage Roles permission.')], ephemeral: true });
    }

    if (!isHigher(moderator, target)) {
      return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot demote this user.')], ephemeral: true });
    }

    if (!botCanActOn(interaction.guild.members.me, target)) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'I cannot manage this user\'s roles.')], ephemeral: true });
    }

    if (!target.roles.cache.has(rankRole.id)) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', 'This user does not have that role.')], ephemeral: true });
    }

    if (rankRole.position >= interaction.guild.members.me.roles.highest.position) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'That role is higher than my highest role.')], ephemeral: true });
    }

    try {
      await target.roles.remove(rankRole, reason);
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', `Could not remove role: ${err.message}`)], ephemeral: true });
    }

    statements.addPromotion.run(
      interaction.guild.id,
      target.id,
      moderator.id,
      'demote',
      rankRole.name,
      'None / Lower',
      reason
    );

    try {
      await target.send({
        embeds: [{
          color: 0xED4245,
          title: 'You have been demoted',
          description: `**Server:** ${interaction.guild.name}\n**Removed Rank:** ${rankRole.name}\n**Reason:** ${reason}\n**By:** ${moderator.user.tag}`,
          timestamp: new Date().toISOString()
        }]
      });
    } catch {}

    await interaction.reply({
      embeds: [
        successEmbed(
          'Member Demoted',
          `**User:** ${target}\n**Removed Rank:** ${rankRole}\n**Reason:** ${reason}`
        )
      ]
    });

    const log = logEmbed(
      '⬇️ Member Demoted',
      `**User:** ${target} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Removed:** ${rankRole.name}\n**Reason:** ${reason}`,
      config.colors.demote
    );
    await sendLog(interaction.guild, 'promotions', log);
  }
};
