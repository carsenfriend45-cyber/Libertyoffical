const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate, isHigher, botCanActOn } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a member')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to mute').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('duration')
        .setDescription('Duration (e.g. 10m, 1h, 1d, 7d)')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for the mute').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason');
    const moderator = interaction.member;

    if (!target) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found in this server.')], ephemeral: true });
    }

    if (!canModerate(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You lack moderation permissions.')], ephemeral: true });
    }

    if (!isHigher(moderator, target)) {
      return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot mute someone with equal or higher roles.')], ephemeral: true });
    }

    if (!botCanActOn(interaction.guild.members.me, target)) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'I cannot act on this user.')], ephemeral: true });
    }

    const durationMs = ms(durationStr);
    if (!durationMs || durationMs < 5000 || durationMs > 28 * 24 * 60 * 60 * 1000) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid Duration', 'Use formats like `10m`, `1h`, `1d`. Max is 28 days.')],
        ephemeral: true
      });
    }

    try {
      await target.timeout(durationMs, reason);
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', `Could not timeout user: ${err.message}`)], ephemeral: true });
    }

    const points = config.points.mute || 2;

    statements.addInfraction.run(
      interaction.guild.id,
      target.id,
      moderator.id,
      'mute',
      reason,
      points,
      durationStr
    );

    const totalPoints = statements.getTotalPoints.get(interaction.guild.id, target.id).total;

    try {
      await target.send({
        embeds: [
          {
            color: 0xFEE75C,
            title: 'You have been muted',
            description: `**Server:** ${interaction.guild.name}\n**Duration:** ${durationStr}\n**Reason:** ${reason}\n**Moderator:** ${moderator.user.tag}`,
            timestamp: new Date().toISOString()
          }
        ]
      });
    } catch {}

    await interaction.reply({
      embeds: [
        successEmbed(
          'User Muted',
          `**User:** ${target}\n**Duration:** ${durationStr}\n**Reason:** ${reason}\n**Points added:** ${points}\n**Total active points:** ${totalPoints}`
        )
      ]
    });

    const log = logEmbed(
      '🔇 Member Muted',
      `**User:** ${target} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Duration:** ${durationStr}\n**Reason:** ${reason}\n**Points:** +${points} (Total: ${totalPoints})`,
      config.colors.mute
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};
