const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearinfractions')
    .setDescription('Clear all active infractions for a user (resets points)')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to clear').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for clearing')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const moderator = interaction.member;

    if (!moderator.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'Administrator only.')], ephemeral: true });
    }

    const before = statements.getTotalPoints.get(interaction.guild.id, target.id).total;
    statements.clearInfractions.run(interaction.guild.id, target.id);

    await interaction.reply({
      embeds: [
        successEmbed(
          'Infractions Cleared',
          `**User:** ${target.tag}\n**Points removed:** ${before}\n**Reason:** ${reason}`
        )
      ]
    });

    const log = logEmbed(
      '🧹 Infractions Cleared',
      `**User:** ${target.tag} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Points removed:** ${before}\n**Reason:** ${reason}`,
      config.colors.success
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};
