const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate, isHigher, botCanActOn } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to kick').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for the kick').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    const moderator = interaction.member;

    if (!target) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found.')], ephemeral: true });
    }

    if (!canModerate(moderator) && !moderator.permissions.has(PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You lack kick permissions.')], ephemeral: true });
    }

    if (!isHigher(moderator, target)) {
      return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot kick this user.')], ephemeral: true });
    }

    if (!botCanActOn(interaction.guild.members.me, target)) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'I cannot kick this user.')], ephemeral: true });
    }

    const points = config.points.kick || 3;

    statements.addInfraction.run(
      interaction.guild.id,
      target.id,
      moderator.id,
      'kick',
      reason,
      points,
      null
    );

    const totalPoints = statements.getTotalPoints.get(interaction.guild.id, target.id).total;

    try {
      await target.send({
        embeds: [{
          color: 0xED4245,
          title: 'You have been kicked',
          description: `**Server:** ${interaction.guild.name}\n**Reason:** ${reason}\n**Moderator:** ${moderator.user.tag}`,
          timestamp: new Date().toISOString()
        }]
      });
    } catch {}

    await target.kick(reason);

    await interaction.reply({
      embeds: [
        successEmbed(
          'User Kicked',
          `**User:** ${target.user.tag}\n**Reason:** ${reason}\n**Points added:** ${points}\n**Total active points:** ${totalPoints}`
        )
      ]
    });

    const log = logEmbed(
      '👢 Member Kicked',
      `**User:** ${target.user.tag} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Reason:** ${reason}\n**Points:** +${points}`,
      config.colors.error
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};
