const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { statements } = require('../../database/db');
const { errorEmbed, infoEmbed } = require('../../utils/embeds');
const { canModerate } = require('../../utils/permissions');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('history')
    .setDescription('View a member\'s infraction history')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to check').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const moderator = interaction.member;

    if (!canModerate(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You lack moderation permissions.')], ephemeral: true });
    }

    const infractions = statements.getInfractions.all(interaction.guild.id, target.id);
    const totalPoints = statements.getTotalPoints.get(interaction.guild.id, target.id).total;
    const notes = statements.getNotes.all(interaction.guild.id, target.id);

    if (infractions.length === 0 && notes.length === 0) {
      return interaction.reply({
        embeds: [infoEmbed('Clean Record', `${target.tag} has no infractions or notes.`)],
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors.info)
      .setTitle(`Infraction History — ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .setDescription(`**Active Points:** ${totalPoints}`)
      .setTimestamp();

    // Show last 10 infractions
    const recent = infractions.slice(0, 10);
    if (recent.length > 0) {
      const list = recent.map(i => {
        const status = i.active ? '🟢' : '⚪';
        return `${status} **#${i.id}** \`${i.type.toUpperCase()}\` — ${i.reason || 'No reason'} (${i.points} pts)\n└ <t:${Math.floor(new Date(i.created_at).getTime() / 1000)}:R> by <@${i.moderator_id}>`;
      }).join('\n\n');
      embed.addFields({ name: `Infractions (${infractions.length})`, value: list || 'None' });
    }

    if (notes.length > 0) {
      const noteList = notes.slice(0, 5).map(n => {
        return `• ${n.content}\n└ <t:${Math.floor(new Date(n.created_at).getTime() / 1000)}:R> by <@${n.moderator_id}>`;
      }).join('\n\n');
      embed.addFields({ name: `Staff Notes (${notes.length})`, value: noteList });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
