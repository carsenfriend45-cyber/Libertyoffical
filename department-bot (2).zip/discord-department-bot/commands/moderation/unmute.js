const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate, isHigher } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove timeout from a member')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to unmute').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for unmute')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const moderator = interaction.member;

    if (!target) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found.')], ephemeral: true });
    }

    if (!canModerate(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You lack permissions.')], ephemeral: true });
    }

    if (!target.isCommunicationDisabled()) {
      return interaction.reply({ embeds: [errorEmbed('Not Muted', 'This user is not currently timed out.')], ephemeral: true });
    }

    try {
      await target.timeout(null, reason);
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Failed', err.message)], ephemeral: true });
    }

    await interaction.reply({
      embeds: [successEmbed('User Unmuted', `**User:** ${target}\n**Reason:** ${reason}`)]
    });

    const log = logEmbed(
      '🔊 Member Unmuted',
      `**User:** ${target} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Reason:** ${reason}`,
      config.colors.success
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};
