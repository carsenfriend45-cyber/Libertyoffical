const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete a number of messages in the channel')
    .addIntegerOption(opt =>
      opt.setName('amount')
        .setDescription('Number of messages to delete (1-100)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    )
    .addUserOption(opt =>
      opt.setName('user').setDescription('Only delete messages from this user')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const targetUser = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    try {
      let deleted;

      if (targetUser) {
        const messages = await interaction.channel.messages.fetch({ limit: 100 });
        const filtered = messages.filter(m => m.author.id === targetUser.id).first(amount);
        deleted = await interaction.channel.bulkDelete(filtered, true);
      } else {
        deleted = await interaction.channel.bulkDelete(amount, true);
      }

      await interaction.editReply({
        embeds: [successEmbed('Messages Purged', `Successfully deleted **${deleted.size}** messages.`)]
      });

      const log = logEmbed(
        '🗑️ Messages Purged',
        `**Channel:** ${interaction.channel}\n**Moderator:** ${interaction.member}\n**Amount:** ${deleted.size}${targetUser ? `\n**Target user:** ${targetUser.tag}` : ''}`,
        config.colors.info
      );
      await sendLog(interaction.guild, 'moderation', log);
    } catch (err) {
      await interaction.editReply({
        embeds: [errorEmbed('Failed', `Could not purge messages: ${err.message}\n(Messages older than 14 days cannot be bulk deleted.)`)]
      });
    }
  }
};
