const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate, isHigher, botCanActOn } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to ban').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for the ban').setRequired(true)
    )
    .addIntegerOption(opt =>
      opt.setName('delete_days')
        .setDescription('Days of messages to delete (0-7)')
        .setMinValue(0)
        .setMaxValue(7)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    const deleteDays = interaction.options.getInteger('delete_days') || 0;
    const moderator = interaction.member;

    if (target) {
      if (!isHigher(moderator, target)) {
        return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot ban this user.')], ephemeral: true });
      }
      if (!botCanActOn(interaction.guild.members.me, target)) {
        return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'I cannot ban this user.')], ephemeral: true });
      }
    }

    const points = config.points.ban || 5;

    statements.addInfraction.run(
      interaction.guild.id,
      targetUser.id,
      moderator.id,
      'ban',
      reason,
      points,
      null
    );

    try {
      await targetUser.send({
        embeds: [{
          color: 0xED4245,
          title: 'You have been banned',
          description: `**Server:** ${interaction.guild.name}\n**Reason:** ${reason}\n**Moderator:** ${moderator.user.tag}`,
          timestamp: new Date().toISOString()
        }]
      });
    } catch {}

    await interaction.guild.members.ban(targetUser.id, {
      reason,
      deleteMessageSeconds: deleteDays * 24 * 60 * 60
    });

    await interaction.reply({
      embeds: [
        successEmbed(
          'User Banned',
          `**User:** ${targetUser.tag}\n**Reason:** ${reason}\n**Messages deleted:** ${deleteDays} day(s)\n**Points added:** ${points}`
        )
      ]
    });

    const log = logEmbed(
      '🔨 Member Banned',
      `**User:** ${targetUser.tag} (\`${targetUser.id}\`)\n**Moderator:** ${moderator}\n**Reason:** ${reason}\n**Delete days:** ${deleteDays}\n**Points:** +${points}`,
      config.colors.ban
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};
