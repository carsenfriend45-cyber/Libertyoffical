const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('note')
    .setDescription('Add a private staff note to a member')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to note').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('content').setDescription('Note content').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const content = interaction.options.getString('content');
    const moderator = interaction.member;

    if (!canModerate(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You lack moderation permissions.')], ephemeral: true });
    }

    statements.addNote.run(
      interaction.guild.id,
      target.id,
      moderator.id,
      content
    );

    await interaction.reply({
      embeds: [successEmbed('Note Added', `Private note added to **${target.tag}**.`)],
      ephemeral: true
    });

    const log = logEmbed(
      '📝 Staff Note Added',
      `**User:** ${target.tag} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Note:** ${content}`,
      config.colors.info
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};
