const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { statements } = require('../../database/db');
const { successEmbed, errorEmbed, logEmbed } = require('../../utils/embeds');
const { canModerate, isHigher, botCanActOn } = require('../../utils/permissions');
const { sendLog } = require('../../utils/logger');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to warn').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for the warning').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    const moderator = interaction.member;

    if (!target) {
      return interaction.reply({ embeds: [errorEmbed('Error', 'User not found in this server.')], ephemeral: true });
    }

    if (!canModerate(moderator)) {
      return interaction.reply({ embeds: [errorEmbed('Permission Denied', 'You lack moderation permissions.')], ephemeral: true });
    }

    if (!isHigher(moderator, target)) {
      return interaction.reply({ embeds: [errorEmbed('Hierarchy Error', 'You cannot warn someone with equal or higher roles.')], ephemeral: true });
    }

    if (!botCanActOn(interaction.guild.members.me, target)) {
      return interaction.reply({ embeds: [errorEmbed('Bot Hierarchy', 'I cannot act on this user (role hierarchy).')], ephemeral: true });
    }

    const points = config.points.warn || 1;

    statements.addInfraction.run(
      interaction.guild.id,
      target.id,
      moderator.id,
      'warn',
      reason,
      points,
      null
    );

    const totalPoints = statements.getTotalPoints.get(interaction.guild.id, target.id).total;

    // Try to DM the user
    try {
      await target.send({
        embeds: [
          warnEmbed('You have been warned', `**Server:** ${interaction.guild.name}\n**Reason:** ${reason}\n**Moderator:** ${moderator.user.tag}\n**Active Points:** ${totalPoints}`)
        ]
      });
    } catch {
      // User has DMs closed
    }

    await interaction.reply({
      embeds: [
        successEmbed(
          'User Warned',
          `**User:** ${target}\n**Reason:** ${reason}\n**Points added:** ${points}\n**Total active points:** ${totalPoints}`
        )
      ]
    });

    // Log
    const log = logEmbed(
      '⚠️ Warning Issued',
      `**User:** ${target} (\`${target.id}\`)\n**Moderator:** ${moderator}\n**Reason:** ${reason}\n**Points:** +${points} (Total: ${totalPoints})`,
      config.colors.warn
    );
    await sendLog(interaction.guild, 'infractions', log);
  }
};

function warnEmbed(title, description) {
  const { EmbedBuilder } = require('discord.js');
  return new EmbedBuilder()
    .setColor(0xFEE75C)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}
