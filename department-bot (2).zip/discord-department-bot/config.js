require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  ownerId: process.env.OWNER_ID,

  // Default colors for embeds
  colors: {
    success: 0x57F287,   // Green
    error: 0xED4245,     // Red
    warn: 0xFEE75C,      // Yellow
    info: 0x5865F2,      // Blurple
    log: 0xEB459E,       // Fuchsia
    promote: 0x57F287,
    demote: 0xED4245,
    mute: 0xFEE75C,
    ban: 0xED4245,
  },

  // Rank hierarchy (lowest to highest) - customize these
  // Format: { name: 'Rank Name', roleId: 'ROLE_ID_HERE', level: number }
  ranks: [
    // Example ranks - replace with your actual role IDs and names
    // { name: 'Cadet', roleId: '1234567890', level: 1 },
    // { name: 'Officer', roleId: '1234567891', level: 2 },
    // { name: 'Sergeant', roleId: '1234567892', level: 3 },
    // { name: 'Lieutenant', roleId: '1234567893', level: 4 },
    // { name: 'Captain', roleId: '1234567894', level: 5 },
    // { name: 'Chief', roleId: '1234567895', level: 6 },
  ],

  // Infraction point values
  points: {
    warn: 1,
    mute: 2,
    kick: 3,
    ban: 5,
  },

  // Auto-escalation thresholds (optional)
  escalation: {
    // points: action
    5: 'mute',
    10: 'kick',
    15: 'ban',
  },

  // Log channel names or IDs (bot will try to find by name if ID not set)
  logs: {
    moderation: null,   // Channel ID for mod logs
    promotions: null,   // Channel ID for promotion logs
    infractions: null,  // Channel ID for infraction logs
  },
};
