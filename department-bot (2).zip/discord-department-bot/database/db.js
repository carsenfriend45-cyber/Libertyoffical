const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'department.db');
const db = new Database(dbPath);

// Enable WAL for better performance
db.pragma('journal_mode = WAL');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS infractions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    moderator_id TEXT NOT NULL,
    type TEXT NOT NULL,          -- warn, mute, kick, ban, note
    reason TEXT,
    points INTEGER DEFAULT 0,
    duration TEXT,                -- for mutes/timeouts
    active INTEGER DEFAULT 1,     -- 1 = active, 0 = inactive/appealed
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS promotions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    moderator_id TEXT NOT NULL,
    action TEXT NOT NULL,         -- promote / demote
    from_rank TEXT,
    to_rank TEXT,
    reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    moderator_id TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    guild_id TEXT PRIMARY KEY,
    mod_log_channel TEXT,
    promo_log_channel TEXT,
    infraction_log_channel TEXT,
    mute_role TEXT,
    prefix TEXT DEFAULT '!'
  );

  CREATE TABLE IF NOT EXISTS blacklists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    reason TEXT,
    moderator_id TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(guild_id, user_id)
  );
`);

// Prepared statements for performance
const statements = {
  // Infractions
  addInfraction: db.prepare(`
    INSERT INTO infractions (guild_id, user_id, moderator_id, type, reason, points, duration)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `),
  getInfractions: db.prepare(`
    SELECT * FROM infractions WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC
  `),
  getActiveInfractions: db.prepare(`
    SELECT * FROM infractions WHERE guild_id = ? AND user_id = ? AND active = 1 ORDER BY created_at DESC
  `),
  getInfractionById: db.prepare(`
    SELECT * FROM infractions WHERE id = ? AND guild_id = ?
  `),
  deactivateInfraction: db.prepare(`
    UPDATE infractions SET active = 0 WHERE id = ? AND guild_id = ?
  `),
  getTotalPoints: db.prepare(`
    SELECT COALESCE(SUM(points), 0) as total FROM infractions 
    WHERE guild_id = ? AND user_id = ? AND active = 1
  `),
  clearInfractions: db.prepare(`
    UPDATE infractions SET active = 0 WHERE guild_id = ? AND user_id = ?
  `),

  // Promotions
  addPromotion: db.prepare(`
    INSERT INTO promotions (guild_id, user_id, moderator_id, action, from_rank, to_rank, reason)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `),
  getPromotions: db.prepare(`
    SELECT * FROM promotions WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC
  `),

  // Notes
  addNote: db.prepare(`
    INSERT INTO notes (guild_id, user_id, moderator_id, content)
    VALUES (?, ?, ?, ?)
  `),
  getNotes: db.prepare(`
    SELECT * FROM notes WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC
  `),

  // Settings
  getSettings: db.prepare(`SELECT * FROM settings WHERE guild_id = ?`),
  setSettings: db.prepare(`
    INSERT INTO settings (guild_id, mod_log_channel, promo_log_channel, infraction_log_channel, mute_role, prefix)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET
      mod_log_channel = excluded.mod_log_channel,
      promo_log_channel = excluded.promo_log_channel,
      infraction_log_channel = excluded.infraction_log_channel,
      mute_role = excluded.mute_role,
      prefix = excluded.prefix
  `),

  // Blacklist
  addBlacklist: db.prepare(`
    INSERT OR REPLACE INTO blacklists (guild_id, user_id, reason, moderator_id)
    VALUES (?, ?, ?, ?)
  `),
  removeBlacklist: db.prepare(`
    DELETE FROM blacklists WHERE guild_id = ? AND user_id = ?
  `),
  isBlacklisted: db.prepare(`
    SELECT * FROM blacklists WHERE guild_id = ? AND user_id = ?
  `),
  getBlacklist: db.prepare(`
    SELECT * FROM blacklists WHERE guild_id = ?
  `),
};

module.exports = { db, statements };
