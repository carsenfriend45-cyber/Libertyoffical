const { PermissionFlagsBits } = require('discord.js');

/**
 * Check if member has moderation permissions
 */
function canModerate(member) {
  return (
    member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
    member.permissions.has(PermissionFlagsBits.KickMembers) ||
    member.permissions.has(PermissionFlagsBits.BanMembers) ||
    member.permissions.has(PermissionFlagsBits.Administrator)
  );
}

/**
 * Check if member can manage roles (for promotions)
 */
function canManageRoles(member) {
  return (
    member.permissions.has(PermissionFlagsBits.ManageRoles) ||
    member.permissions.has(PermissionFlagsBits.Administrator)
  );
}

/**
 * Check if the bot can act on a target member
 */
function botCanActOn(botMember, targetMember) {
  if (targetMember.id === botMember.guild.ownerId) return false;
  if (targetMember.roles.highest.position >= botMember.roles.highest.position) return false;
  return true;
}

/**
 * Check hierarchy between two members
 */
function isHigher(moderator, target) {
  if (target.id === target.guild.ownerId) return false;
  return moderator.roles.highest.position > target.roles.highest.position;
}

module.exports = {
  canModerate,
  canManageRoles,
  botCanActOn,
  isHigher,
};
