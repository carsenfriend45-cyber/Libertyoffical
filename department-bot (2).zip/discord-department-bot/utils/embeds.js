const { EmbedBuilder } = require('discord.js');
const config = require('../config');

function successEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(config.colors.success)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

function errorEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(config.colors.error)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

function infoEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(config.colors.info)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

function warnEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(config.colors.warn)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

function logEmbed(title, description, color = config.colors.log) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

function userInfoEmbed(member, infractions, points, notes, promotions) {
  const roles = member.roles.cache
    .filter(r => r.id !== member.guild.id)
    .sort((a, b) => b.position - a.position)
    .map(r => r.toString())
    .slice(0, 15)
    .join(', ') || 'None';

  return new EmbedBuilder()
    .setColor(config.colors.info)
    .setTitle(`User Info — ${member.user.tag}`)
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: 'ID', value: member.id, inline: true },
      { name: 'Nickname', value: member.nickname || 'None', inline: true },
      { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
      { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
      { name: 'Roles', value: roles.length > 1024 ? roles.slice(0, 1020) + '...' : roles },
      { name: 'Active Points', value: `${points}`, inline: true },
      { name: 'Infractions', value: `${infractions.length}`, inline: true },
      { name: 'Notes', value: `${notes.length}`, inline: true },
      { name: 'Promotion History', value: `${promotions.length}`, inline: true },
    )
    .setTimestamp();
}

module.exports = {
  successEmbed,
  errorEmbed,
  infoEmbed,
  warnEmbed,
  logEmbed,
  userInfoEmbed,
};
