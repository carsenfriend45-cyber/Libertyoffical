const { statements } = require('../database/db');
const { logEmbed } = require('./embeds');
const config = require('../config');

async function sendLog(guild, type, embed) {
  try {
    const settings = statements.getSettings.get(guild.id);
    let channelId = null;

    if (type === 'moderation' || type === 'infractions') {
      channelId = settings?.mod_log_channel || settings?.infraction_log_channel || config.logs.moderation;
    } else if (type === 'promotions') {
      channelId = settings?.promo_log_channel || config.logs.promotions;
    }

    if (!channelId) {
      // Try to find a channel named "mod-logs" or "logs"
      const logChannel = guild.channels.cache.find(
        c => c.name.includes('mod-log') || c.name.includes('staff-log') || c.name === 'logs'
      );
      if (logChannel) channelId = logChannel.id;
    }

    if (channelId) {
      const channel = await guild.channels.fetch(channelId).catch(() => null);
      if (channel) {
        await channel.send({ embeds: [embed] });
      }
    }
  } catch (err) {
    console.error('Failed to send log:', err.message);
  }
}

module.exports = { sendLog };
